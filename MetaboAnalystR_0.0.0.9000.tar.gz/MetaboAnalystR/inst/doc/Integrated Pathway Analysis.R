## ---- eval=FALSE---------------------------------------------------------
#  # Initiate MetaboAnalyst
#  mSet <- InitDataObjects("conc", "inmex", FALSE)
#  
#  mSet <- SetOrganism(mSet, "hsa")
#  
#  genes <- c(1737, 83440, 3939, 10911)
#  
#  mSet<-PerformIntegGeneMapping(mSet, genes, "hsa", "entrez")
#  
#  mSet<-PerformIntegGeneMapping("#Entrez  logFC
#                          1737  -1.277784317
#                          83440  -1.034136439
#                          3939  -2.231729728
#                          10911  -1.045657875
#                          10690  -0.968308832
#                          10010  -0.861541301
#                          10053  0.360090661", "hsa", "entrez")
#  
#  mSet<-PerformIntegCmpdMapping(mSet, cmpds, "hsa", "kegg")
#  
#  mSet<-PerformIntegCmpdMapping("#KEGG  logFC
#                          C00116  1.010972619
#                          C00565  -0.714283001
#                          C00033  0.822193121
#                          C00583  -1.005192252
#                          C00022  -0.623838569
#                          C00719  -0.406052491
#                          C05984  -0.390152174
#                          C00407  -0.238389886
#                          C00791  0.489764981
#                          C00062  0.291549231
#                          C00300  -0.230475941", "hsa", "kegg")
#  
#  cmpds <- c(C00116, C00565, C00033, C00583)
#  
#  mSet<-PrepareIntegData(mSet)
#  

## ---- eval=FALSE---------------------------------------------------------
#  # Perform integrated pathway analysis, using hypergeometric test, degree centrality, and the gene-metabolite pathways
#  mSet<-PerformIntegPathwayAnalysis(mSet, "dc", "hyper", "integ")
#  
#  # Perform integrated pathway analysis, using hypergeometric test, betweenness centrality, and gene-centric pathways
#  mSet<-PerformIntegPathwayAnalysis(mSet, "bc", "hyper", "genetic")
#  

## ---- eval=FALSE---------------------------------------------------------
#  # Perform pathway analysis
#  mSet<-PlotInmexPath(mSet, "hsa00260", 636, 513)
#  
#  # Create the KEGG graph
#  mSet<-RerenderKEGGGraph(mSet, "zoom1502130707551.png",636.0, 513.0, 100.0)
#  

